package com.example

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.theme.MyApplicationTheme
import com.google.firebase.FirebaseApp
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.remoteConfigSettings

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize()
                ) { innerPadding ->
                    WebViewAppScreen(
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebViewAppScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val defaultUrl = "https://app.arthafin.web.id"
    var webUrl by remember { mutableStateOf(defaultUrl) }
    var isConfigLoaded by remember { mutableStateOf(false) }
    var pageLoadingProgress by remember { mutableStateOf(0) }
    var isPageLoading by remember { mutableStateOf(true) }
    
    var webViewInstance by remember { mutableStateOf<WebView?>(null) }

    // Handle back press to navigate back in WebView history if possible
    BackHandler(enabled = webViewInstance?.canGoBack() == true) {
        webViewInstance?.goBack()
    }

    LaunchedEffect(Unit) {
        try {
            // Check and initialize Firebase if not initialized
            if (FirebaseApp.getApps(context).isEmpty()) {
                FirebaseApp.initializeApp(context)
            }
            
            val remoteConfig = FirebaseRemoteConfig.getInstance()
            val configSettings = remoteConfigSettings {
                minimumFetchIntervalInSeconds = 0 // Fetch immediately on app launch
            }
            remoteConfig.setConfigSettingsAsync(configSettings)
            
            // Set default key-value maps
            val defaultMap = mapOf<String, Any>(
                "https://app.arthafin.web.id" to defaultUrl
            )
            remoteConfig.setDefaultsAsync(defaultMap)

            remoteConfig.fetchAndActivate()
                .addOnCompleteListener { task ->
                    val fetchedUrl = if (task.isSuccessful) {
                        remoteConfig.getString("https://app.arthafin.web.id")
                    } else {
                        ""
                    }
                    
                    // Fallback if fetched URL is empty or invalid
                    webUrl = if (fetchedUrl.isNotBlank() && fetchedUrl.startsWith("http")) {
                        fetchedUrl
                    } else {
                        defaultUrl
                    }
                    isConfigLoaded = true
                }
        } catch (e: Exception) {
            // Handle cases where Google Play Services or Firebase is unavailable gracefully
            android.util.Log.e("MainActivity", "Firebase Remote Config error: ${e.message}", e)
            webUrl = defaultUrl
            isConfigLoaded = true
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        if (!isConfigLoaded) {
            // Beautiful minimalist splash loader while getting URL
            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center
            ) {
                CircularProgressIndicator(
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(bottom = 16.dp)
                )
                Text(
                    text = "Menghubungkan ke ArthaFin...",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }
        } else {
            // Main WebView Interface
            Box(modifier = Modifier.fillMaxSize()) {
                AndroidView(
                    factory = { ctx ->
                        WebView(ctx).apply {
                            webViewClient = object : WebViewClient() {
                                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                                    super.onPageStarted(view, url, favicon)
                                    isPageLoading = true
                                    pageLoadingProgress = 0
                                }

                                override fun onPageFinished(view: WebView?, url: String?) {
                                    super.onPageFinished(view, url)
                                    isPageLoading = false
                                }

                                override fun shouldOverrideUrlLoading(
                                    view: WebView?,
                                    request: WebResourceRequest?
                                ): Boolean {
                                    // Make sure any links clicked inside the WebView stay inside the WebView
                                    // This hides the standard browser address bar of external browsers
                                    val requestUrl = request?.url?.toString() ?: ""
                                    view?.loadUrl(requestUrl)
                                    return true
                                }
                            }

                            // Custom WebChromeClient to track loading progress
                            webChromeClient = object : android.webkit.WebChromeClient() {
                                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                                    super.onProgressChanged(view, newProgress)
                                    pageLoadingProgress = newProgress
                                    if (newProgress == 100) {
                                        isPageLoading = false
                                    }
                                }
                            }

                            // Modern secure webview configurations
                            settings.apply {
                                javaScriptEnabled = true
                                domStorageEnabled = true
                                useWideViewPort = true
                                loadWithOverviewMode = true
                                setSupportZoom(true)
                                builtInZoomControls = true
                                displayZoomControls = false
                                
                                // Disable mixed content if not needed, or allow it specifically if the site requires it
                                mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                                
                                // Enable cache settings
                                cacheMode = WebSettings.LOAD_DEFAULT
                            }
                            
                            // Initialize with webUrl
                            loadUrl(webUrl)
                            webViewInstance = this
                        }
                    },
                    update = { webView ->
                        // If the URL changes dynamically from Config, we can load the new URL
                        if (webView.url != webUrl) {
                            webView.loadUrl(webUrl)
                        }
                        webViewInstance = webView
                    },
                    modifier = Modifier.fillMaxSize()
                )

                // Inline beautiful Material 3 page loading bar at the top of the screen
                AnimatedVisibility(
                    visible = isPageLoading,
                    enter = fadeIn(),
                    exit = fadeOut(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.TopStart)
                ) {
                    LinearProgressIndicator(
                        progress = { pageLoadingProgress / 100f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(3.dp),
                        color = MaterialTheme.colorScheme.primary,
                        trackColor = Color.Transparent
                    )
                }
            }
        }
    }
}
